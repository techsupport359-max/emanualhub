-- Apply in Supabase SQL Editor before enabling the custom manual request workflow.
create table if not exists public.custom_manual_requests (
  id uuid primary key default gen_random_uuid(),
  customer_email text not null,
  category text not null,
  brand text not null,
  model text not null,
  model_year text,
  variant text,
  manual_type text not null,
  details text not null,
  status text not null default 'requested',
  amount_usd_cents integer check (amount_usd_cents is null or amount_usd_cents > 0),
  paypal_order_id text unique,
  paypal_capture_id text unique,
  paid_at timestamptz,
  delivered_at timestamptz,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
-- Safe migration for an existing version of this table:
alter table public.custom_manual_requests alter column amount_usd_cents drop not null;
alter table public.custom_manual_requests alter column amount_usd_cents drop default;
alter table public.custom_manual_requests alter column status set default 'requested';
alter table public.custom_manual_requests drop constraint if exists custom_manual_requests_status_check;
alter table public.custom_manual_requests add constraint custom_manual_requests_status_check check (status in ('requested','in_progress','delivered_pending_payment','payment_pending','paid','delivered','cancelled','refunded'));
create index if not exists custom_manual_requests_status_created_idx on public.custom_manual_requests(status, created_at desc);
alter table public.custom_manual_requests enable row level security;
-- No public RLS policies. Access is server-only using SUPABASE_SERVICE_ROLE_KEY.
