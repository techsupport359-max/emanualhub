-- Run this migration in the Supabase SQL Editor before enabling PayPal checkout.
-- This table binds the checkout email/manual to the PayPal order before capture.
create table if not exists public.paypal_deliveries (
  id uuid primary key default gen_random_uuid(),
  paypal_order_id text not null unique,
  paypal_capture_id text unique,
  customer_email text not null,
  manual_slug text not null,
  amount_usd_cents integer not null check (amount_usd_cents > 0),
  status text not null default 'pending' check (status in ('pending','paid','email_failed','delivered')),
  last_error text,
  created_at timestamptz not null default now(),
  delivered_at timestamptz
);
alter table public.paypal_deliveries enable row level security;
-- No public policies: access only from server routes using the Supabase service-role key.
