-- eManuals Hub starter schema. Apply only to a new Supabase project after reviewing.
create extension if not exists pgcrypto;

create type public.manual_status as enum ('draft', 'published', 'archived');
create type public.order_status as enum ('pending', 'paid', 'failed', 'refunded');
create type public.purchase_kind as enum ('single', 'subscription');

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  description text,
  created_at timestamptz not null default now()
);

create table public.manuals (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  brand text not null,
  model text not null,
  model_year_from int,
  model_year_to int,
  document_type text not null,
  language text not null default 'English',
  page_count int,
  file_size_bytes bigint,
  price_inr_paise int not null default 0 check (price_inr_paise >= 0),
  price_usd_cents int not null default 0 check (price_usd_cents >= 0),
  description text not null default '',
  compatibility_notes text not null default '',
  storage_path text, -- private bucket path only; never expose public storage URLs
  rights_verified boolean not null default false,
  status public.manual_status not null default 'draft',
  category_id uuid references public.categories(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint valid_year_range check (
    model_year_from is null or model_year_to is null or model_year_from <= model_year_to
  )
);

create index manuals_search_idx on public.manuals using gin (
  to_tsvector('english', coalesce(title,'') || ' ' || coalesce(brand,'') || ' ' ||
  coalesce(model,'') || ' ' || coalesce(document_type,'') || ' ' || coalesce(description,''))
);
create index manuals_category_idx on public.manuals(category_id, status);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  kind public.purchase_kind not null default 'single',
  status public.order_status not null default 'pending',
  currency text not null check (currency in ('INR','USD')),
  amount_minor int not null check (amount_minor >= 0),
  payment_provider text,
  provider_order_id text unique,
  provider_payment_id text unique,
  created_at timestamptz not null default now(),
  paid_at timestamptz
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  manual_id uuid not null references public.manuals(id) on delete restrict,
  unit_amount_minor int not null check (unit_amount_minor >= 0),
  unique(order_id, manual_id)
);

create table public.entitlements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  manual_id uuid references public.manuals(id) on delete cascade,
  order_id uuid references public.orders(id) on delete set null,
  subscription_provider_id text,
  starts_at timestamptz not null default now(),
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  check (manual_id is not null or subscription_provider_id is not null)
);
create index entitlements_user_idx on public.entitlements(user_id, expires_at);

create table public.download_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  manual_id uuid not null references public.manuals(id) on delete cascade,
  created_at timestamptz not null default now(),
  outcome text not null default 'issued'
);

alter table public.categories enable row level security;
alter table public.manuals enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.entitlements enable row level security;
alter table public.download_events enable row level security;

-- Public users can read published manuals only; no storage path is exposed via client API in production.
create policy "published manuals are readable" on public.manuals
  for select using (status = 'published' and rights_verified = true);
create policy "categories are readable" on public.categories for select using (true);

-- Orders, entitlements and download logs intentionally have no client policies.
-- Access them through authenticated server routes after verifying user identity.
-- Admin writes must use a server-side role check; never ship SUPABASE_SERVICE_ROLE_KEY to a browser.


-- Customer support tickets. Private by default; no public select policy.
create type public.support_ticket_status as enum ('open', 'in_progress', 'waiting_customer', 'resolved', 'closed');
create table public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  customer_email text not null,
  order_reference text,
  topic text not null check (topic in ('manual_request','compatibility','payment','download','membership','other')),
  subject text not null,
  message text not null,
  status public.support_ticket_status not null default 'open',
  assigned_to uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index support_tickets_status_created_idx on public.support_tickets(status, created_at desc);
alter table public.support_tickets enable row level security;
-- Intentionally no public ticket read/write policies. Implement server-side validation,
-- CAPTCHA/rate limiting, and auth/ownership checks before enabling the API.
