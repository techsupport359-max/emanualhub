import FastDeliveryNotice from "@/components/FastDeliveryNotice";
import Link from "next/link";
import CatalogueNav from "@/components/CatalogueNav";

const categories = [
  { icon: "🚗", title: "Cars & Trucks", text: "Workshop, service and repair manuals" },
  { icon: "🏍️", title: "Motorcycles", text: "Maintenance and troubleshooting guides" },
  { icon: "🚜", title: "Tractors & Agriculture", text: "Farm machinery and equipment manuals" },
  { icon: "🏗️", title: "Cranes & Heavy Equipment", text: "Technical guides for heavy machinery" },
  { icon: "📱", title: "Phones & Electronics", text: "Repair and service documentation" },
  { icon: "💻", title: "Laptops & Computers", text: "Hardware, service and maintenance guides" },
  { icon: "🏠", title: "Home Appliances", text: "Appliance service and repair guides" },
  { icon: "⚙️", title: "Industrial Equipment", text: "Technical documents and parts guides" },
  { icon: "🛠️", title: "CAT & Construction Machines", text: "Caterpillar loaders, excavators and engines" },
  { icon: "🌾", title: "John Deere Manuals", text: "Tractors, harvesters and farm equipment" },
  { icon: "📲", title: "Tablets & iPads", text: "Tablet, iPad and device service guides" },
  { icon: "🍎", title: "MacBook & Apple Devices", text: "MacBook, iMac and Apple device guides" },
];

export default function Home() {
  return (
    <>
      <header className="topbar">
        <div className="container nav">
          <Link href="/" className="brand"><span className="brand-mark">e</span><span>eManuals <span style={{color:"#69b5ff"}}>Hub</span><small style={{display:"block",fontSize:".68rem",fontWeight:400,letterSpacing:0,color:"#c5d3e6"}}>All Manuals. One Place.</small></span></Link>
          <nav className="navlinks"><CatalogueNav /><Link href="/vehicles">Vehicle Manuals</Link><Link href="/equipment">Equipment</Link><Link href="/phones">Phone Repair</Link><Link href="/support">Support</Link><Link href="/blog">Blog</Link><Link href="/faqs">FAQs</Link></nav>
          <div style={{display:"flex",gap:10,flexWrap:"wrap"}}><Link className="btn" href="/catalog">Browse & Buy Manuals</Link><Link className="btn btn-secondary" href="/request-manual">Request a Custom Manual</Link></div>
        </div>
      </header>
      <main>
        <section className="hero hero-photo">
          <div className="container hero-grid">
            <div>
              <div className="eyebrow">Repair knowledge, made accessible</div>
              <h1>Find the right manual.<br/><span style={{color:"#67b4ff"}}>Fix with confidence.</span></h1>
              <p className="lead">Discover service, repair, wiring and technical manuals for vehicles, electronics and equipment — all in one place.</p>
              <form id="search" className="searchbox" action="/catalog">
                <input name="q" placeholder="Search brand, model, year or part number…" aria-label="Search manuals"/>
                <button className="btn" type="submit">Search manuals →</button>
              </form>
              <p style={{fontSize:".8rem",color:"#b9cbe0",marginTop:12}}>Search by make, model, year or product number.</p>
            </div>
            <div className="hero-photo-card" aria-label="Automotive service photo">
              <img src="https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?auto=format&fit=crop&w=1200&q=85" alt="Mechanic inspecting a vehicle in a workshop" />
              <div className="photo-caption"><strong>Built for hands-on repairs</strong><span>Service information for the machines you rely on.</span></div>
            </div>
            <div className="hero-card">
              <div className="eyebrow">The eManuals Hub promise</div>
              <h3 style={{fontSize:"1.5rem",marginBottom:8}}>Technical help, all in one library.</h3>
              <p style={{color:"#d3deed",lineHeight:1.65}}>A growing catalogue of carefully described digital manuals, with clear compatibility details before checkout.</p>
              <div className="hero-stat"><span>Digital manuals</span><strong>PDF-ready</strong></div>
              <div className="hero-stat"><span>Checkout</span><strong>Secure payment</strong></div>
              <div className="hero-stat"><span>After purchase</span><strong>Protected download</strong></div>
              <div className="hero-stat"><span>Need help?</span><strong>Private Help Centre</strong></div>
            </div>
          </div>
        </section>
        <div className="container"><FastDeliveryNotice /></div>
        <section className="trust"><div className="container trust-grid">
          <div className="trust-item">⚡ Fast manual delivery<span>Delivered by email as quickly as possible</span></div>
          <div className="trust-item">🔒 Secure checkout<span>Provider-hosted payment flow</span></div>
          <div className="trust-item">💬 Human support<span>WhatsApp and email assistance</span></div>
          <div className="trust-item">🌐 Global-ready<span>India and international plans</span></div>
        </div></section>
        <section id="categories" className="section technical-bg">
          <div className="container">
            <div className="section-head"><div><h2>Browse by category</h2><p className="muted" style={{margin:0}}>Start with a product type, then narrow by brand and model.</p></div></div>
            <div className="photo-category-grid">
              <Link href="/vehicles" className="photo-category"><img src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1000&q=85" alt="Modern car"/><span className="photo-shade"/><span className="photo-category-copy"><small>VEHICLES</small><strong>Cars & SUVs</strong><em>Explore workshop manuals ↗</em></span></Link>
              <Link href="/vehicles" className="photo-category"><img src="https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=1000&q=85" alt="Motorcycle"/><span className="photo-shade"/><span className="photo-category-copy"><small>POWERSPORTS</small><strong>Motorcycles & ATVs</strong><em>Explore service manuals ↗</em></span></Link>
              <Link href="/vehicles" className="photo-category"><img src="https://images.unsplash.com/photo-1519003722824-194d4455a60c?auto=format&fit=crop&w=1000&q=85" alt="Commercial truck"/><span className="photo-shade"/><span className="photo-category-copy"><small>COMMERCIAL</small><strong>Trucks & Buses</strong><em>Explore fleet documentation ↗</em></span></Link>
              <Link href="/equipment" className="photo-category"><img src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1000&q=85" alt="Agriculture field"/><span className="photo-shade"/><span className="photo-category-copy"><small>AGRICULTURE</small><strong>Tractors & Farm Equipment</strong><em>Explore operator guides ↗</em></span></Link>
              <Link href="/equipment" className="photo-category"><img src="https://images.unsplash.com/photo-1580901368919-7738efb0f87e?auto=format&fit=crop&w=1000&q=85" alt="Heavy construction machinery"/><span className="photo-shade"/><span className="photo-category-copy"><small>HEAVY MACHINERY</small><strong>Cranes & Construction</strong><em>Explore equipment manuals ↗</em></span></Link>
              <Link href="/phones" className="photo-category"><img src="https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=1000&q=85" alt="Smartphone"/><span className="photo-shade"/><span className="photo-category-copy"><small>ELECTRONICS</small><strong>Phones, Tablets & Computers</strong><em>Explore repair guides ↗</em></span></Link>
            </div>
            <div className="grid-cats secondary-cats">{categories.slice(3).map(c=><Link className="category" key={c.title} href={c.title.includes("Cars") || c.title.includes("Motorcycles") ? "/vehicles" : c.title.includes("Tractors") || c.title.includes("Heavy") || c.title.includes("Industrial") || c.title.includes("CAT") || c.title.includes("John Deere") ? "/equipment" : "/phones"}><div className="category-icon">{c.icon}</div><h3>{c.title}</h3><p>{c.text}</p><span className="category-link">Explore manuals ↗</span></Link>)}</div>
            <div className="section-head" style={{marginTop:42}}><div><h2>Brands & device families</h2><p className="muted" style={{margin:0}}>Explore manuals by manufacturer or product family. Availability depends on the catalogue.</p></div></div>
            <div className="brand-chip-grid">
              {[{name:"Toyota · Ford · BMW · Honda",q:"car workshop manuals"},{name:"Yamaha · Kawasaki · Harley-Davidson",q:"motorcycle service manuals"},{name:"John Deere · New Holland · Kubota",q:"tractor service manuals"},{name:"Caterpillar (CAT) · Komatsu · JCB",q:"heavy equipment manuals"},{name:"Cranes · Excavators · Bulldozers",q:"crane excavator bulldozer manuals"},{name:"iPhone · Samsung · Google Pixel",q:"smartphone repair manuals"},{name:"iPad · Android Tablets",q:"tablet repair manuals"},{name:"MacBook · iMac · Windows Laptops",q:"laptop computer service manuals"}].map(b=><Link className="brand-chip" key={b.name} href={`/manuals?q=${encodeURIComponent(b.q)}`}><span>{b.name}</span><strong>Search manuals ↗</strong></Link>)}
            </div>
          </div>
        </section>
        <section id="how-it-works" className="section technical-bg soft-section">
          <div className="container">
            <div className="section-head"><div><h2>Simple from search to download</h2><p className="muted" style={{margin:0}}>The production checkout will unlock files only after verified payment.</p></div></div>
            <div className="feature-grid">
              <article className="feature"><div className="category-icon">🔎</div><h3>1. Find your manual</h3><p className="muted">Search by make, model, year or document type.</p></article>
              <article className="feature"><div className="category-icon">💳</div><h3>2. Buy or subscribe</h3><p className="muted">Choose a one-time purchase or an eligible membership plan.</p></article>
              <article className="feature"><div className="category-icon">📥</div><h3>3. Download securely</h3><p className="muted">Access purchased manuals through your account with protected links.</p></article>
            </div>
          </div>
        </section>
        <section id="support" className="section"><div className="container feature-grid">
          <article className="feature"><div className="category-icon">💬</div><h3>Private customer help</h3><p className="muted">Open a support request without publishing a personal phone number on the website.</p><a className="btn" href="/support">Open Help Centre</a></article>
          <article className="feature"><div className="category-icon">✉️</div><h3>Email support</h3><p className="muted">Send order questions and manual requests to our support inbox.</p><a className="btn btn-secondary" href="mailto:emanualshub@gmail.com">emanualshub@gmail.com</a></article>
          <article className="feature"><div className="category-icon">📚</div><h3>Missing a manual?</h3><p className="muted">Ask us to check availability for your exact make, model and year.</p><Link className="btn btn-secondary" href="/request-manual">Request a manual</Link></article>
        </div></section>
      </main>
      <footer className="footer"><div className="container footer-row"><div className="brand"><span className="brand-mark">e</span><span>eManuals Hub<small style={{display:"block",fontSize:".7rem",fontWeight:400}}>All Manuals. One Place.</small></span></div><div>© {new Date().getFullYear()} eManuals Hub · Digital manuals marketplace</div><div><a href="mailto:emanualshub@gmail.com">Contact support</a></div></div></footer>
    </>
  );
}
