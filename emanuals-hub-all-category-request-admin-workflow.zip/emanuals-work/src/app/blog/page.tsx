import Link from "next/link";
import SiteHeader from "@/components/SiteHeader";
const posts = [
 ["How to identify your vehicle model year","Find the VIN/model plate, confirm engine and trim, and compare them with the manual listing."],
 ["Workshop manual vs owner's manual","Owner guides explain controls and routine use; workshop manuals cover technical service and repair procedures."],
 ["Before you start a repair","Use the correct model-specific documentation, follow safety warnings, and use a qualified technician when needed."]
];
export default function BlogPage(){return <><SiteHeader/><main className="catalog-page technical-bg"><div className="container"><div className="catalog-hero"><div className="eyebrow">Repair knowledge</div><h1>eManuals Hub <span className="blue-text">Blog</span></h1><p className="lead">Practical tips for finding the right documentation and preparing for repairs.</p></div><div className="catalog-grid">{posts.map(([title,desc])=><article className="feature catalog-card" key={title}><h2>{title}</h2><p className="muted">{desc}</p><Link className="text-link" href="/catalog">Browse manuals →</Link></article>)}</div></div></main></>}
