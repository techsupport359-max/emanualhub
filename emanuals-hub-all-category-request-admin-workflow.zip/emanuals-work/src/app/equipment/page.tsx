import SiteHeader from "@/components/SiteHeader";
import Link from "next/link";
const items = [
  ["🚜", "Tractor service manuals", "John Deere, Kubota, Massey Ferguson, New Holland, Case IH and Mahindra"],
  ["🐈", "Caterpillar (CAT) machines", "CAT excavators, wheel loaders, dozers, engines and generators"],
  ["🌾", "John Deere farm equipment", "Tractors, combines, harvesters, planters and agricultural machinery"],
  ["🚧", "Excavators & diggers", "Mini excavators, crawler excavators and backhoe loaders"],
  ["🏗️", "Cranes & lifting equipment", "Mobile cranes, tower cranes, telehandlers and lifting systems"],
  ["🚜", "Bulldozers, loaders & graders", "Earthmoving, road-building and site-preparation equipment"],
  ["⚙️", "Komatsu, JCB, Volvo CE & Hitachi", "Construction equipment service and parts documentation"],
  ["🏭", "Industrial machines & generators", "Forklifts, compressors, pumps, engines and factory equipment"],
  ["🌱", "Harvesters & agricultural implements", "Combines, balers, sprayers, seeders and attachments"],
];
export default function EquipmentPage() { return <><SiteHeader/><main className="catalog-page technical-bg"><div className="container"><Link className="back-link" href="/">← Back to eManuals Hub</Link><div className="catalog-hero"><div className="eyebrow">Machinery library</div><h1>Tractors, Cranes & <span className="blue-text">Heavy Machines</span></h1><p className="lead">Explore agricultural, construction, lifting and industrial equipment categories. Search by manufacturer, model and serial number family, and verify availability before ordering.</p><form className="searchbox catalog-search" action="/manuals"><input name="q" placeholder="Try CAT 320, John Deere, JCB or Kubota…" aria-label="Search equipment manuals"/><button className="btn" type="submit">Search manuals →</button></form></div><div className="catalog-grid">{items.map(([icon,item,desc])=><article className="feature catalog-card" key={item}><div className="category-icon">{icon}</div><h3>{item}</h3><p className="muted">{desc}</p><Link className="text-link" href={`/manuals?q=${encodeURIComponent(item)}`}>Find a manual →</Link></article>)}</div><p className="catalog-note">Manufacturer and model names help identify the right documentation; they do not imply an official manufacturer relationship. Always follow the manufacturer's safety procedures.</p></div></main></> }
