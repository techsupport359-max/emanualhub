import Link from "next/link";
import SiteHeader from "@/components/SiteHeader";
const categories = [
  {
    "icon": "🚗",
    "title": "Cars",
    "slug": "cars",
    "href": "/catalog?category=Cars"
  },
  {
    "icon": "🚚",
    "title": "Buses & Trucks",
    "slug": "commercial",
    "href": "/catalog?category=Commercial%20Vehicles"
  },
  {
    "icon": "🚜",
    "title": "Agriculture & Tractors",
    "slug": "agriculture",
    "href": "/catalog?category=Agriculture"
  },
  {
    "icon": "🏗️",
    "title": "Construction & Heavy Equipment",
    "slug": "construction",
    "href": "/catalog?category=Construction"
  },
  {
    "icon": "🏍️",
    "title": "Motorbikes & Powersports",
    "slug": "motorbikes",
    "href": "/catalog?category=Motorcycles"
  },
  {
    "icon": "⚙️",
    "title": "Business & Industrial",
    "slug": "industrial",
    "href": "/catalog?category=Business%20%26%20Industrial"
  },
  {
    "icon": "📱",
    "title": "Phones & Tablets",
    "slug": "phones",
    "href": "/catalog?category=Phones%20%26%20Tablets"
  },
  {
    "icon": "💻",
    "title": "Laptops & Computers",
    "slug": "computers",
    "href": "/catalog?category=Laptops%20%26%20Computers"
  },
  {
    "icon": "🚤",
    "title": "Marine",
    "slug": "marine",
    "href": "/catalog?category=Marine"
  },
  {
    "icon": "🔧",
    "title": "Engines & Electrical",
    "slug": "engines",
    "href": "/catalog?category=Engines%20%26%20Electrical"
  },
  {
    "icon": "🏠",
    "title": "Home & Garden",
    "slug": "home",
    "href": "/catalog?category=Home%20%26%20Garden"
  },
  {
    "icon": "📚",
    "title": "Education & Technical Guides",
    "slug": "education",
    "href": "/catalog?category=Education"
  }
] as const;
export default function CategoriesPage(){return <><SiteHeader/><main className="catalog-page technical-bg"><div className="container"><div className="catalog-hero"><div className="eyebrow">Browse by one specific category</div><h1>Manual <span className="blue-text">Categories</span></h1><p className="lead">Choose one category first. The next page filters to that category, then lets you narrow by brand, model, year and document type. Only verified files are shown as available manuals.</p></div><div className="catalog-grid">{categories.map(c=><article className="feature catalog-card" key={c.slug}><div className="category-icon">{c.icon}</div><h2>{c.title}</h2><p className="muted">Open this category only, then browse its brands and available manuals.</p><Link className="text-link" href={c.href}>Open {c.title} →</Link></article>)}</div></div></main></>}
