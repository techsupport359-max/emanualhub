import Link from 'next/link';
import { notFound } from 'next/navigation';
import { products, getCompetitivePriceUSD } from '@/lib/catalog';
import { CurrencyPrice } from '@/components/CurrencyProvider';
import { PayPalCheckout } from '@/components/PayPalCheckout';

export default async function CheckoutPage({searchParams}:{searchParams:Promise<{slug?:string}>}) {
  const {slug=''} = await searchParams;
  const p = products.find(item => item.slug === slug);
  if (!p) return notFound();
  const price = getCompetitivePriceUSD(p);
  return <main style={{maxWidth:1060,margin:'42px auto',padding:'24px',color:'#10223a'}}>
    <Link href={`/catalog/${p.slug}`} style={{color:'#1265b0',fontWeight:700,textDecoration:'none'}}>← Back to manual</Link>
    <header style={{margin:'24px 0 28px'}}><p style={{fontSize:12,letterSpacing:2,fontWeight:800,color:'#1265b0'}}>SECURE DIGITAL CHECKOUT</p><h1 style={{fontSize:'clamp(2rem,5vw,3rem)',margin:'8px 0'}}>Complete your order</h1><p style={{color:'#60758b',lineHeight:1.7}}>Enter the email address where you want the PDF delivered. This project is configured for PayPal Sandbox testing only.</p></header>
    <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))',gap:22,alignItems:'start'}}>
      <section style={{border:'1px solid #dce5ef',borderRadius:18,padding:24,background:'#fff',boxShadow:'0 10px 28px #1836540b'}}>
        <h2 style={{marginTop:0}}>Order details</h2><div style={{display:'flex',gap:16,alignItems:'start',padding:'16px 0',borderTop:'1px solid #e5edf5',borderBottom:'1px solid #e5edf5'}}><div aria-hidden="true" style={{width:74,height:96,flexShrink:0,borderRadius:8,background:'linear-gradient(145deg,#10233a,#2674b9)',color:'white',display:'grid',placeItems:'center',textAlign:'center',fontWeight:800,fontSize:11,padding:8}}>eManuals<br/>HUB<br/>PDF</div><div style={{flex:1}}><h3 style={{fontSize:17,margin:'2px 0 8px'}}>{p.title}</h3><p style={{fontSize:13,color:'#60758b',margin:'0 0 8px'}}>{p.brand} · {p.model} · {p.year}</p><span style={{fontSize:12,color:'#087f5b',fontWeight:700}}>Digital PDF guide</span></div><strong style={{whiteSpace:'nowrap'}}><CurrencyPrice usd={price}/></strong></div>
        <div style={{display:'flex',justifyContent:'space-between',padding:'18px 0 8px'}}><span style={{color:'#60758b'}}>Subtotal</span><strong><CurrencyPrice usd={price}/></strong></div><div style={{display:'flex',justifyContent:'space-between',padding:'8px 0 18px',borderBottom:'1px solid #e5edf5'}}><span style={{color:'#60758b'}}>Delivery</span><strong>Digital · $0.00</strong></div><div style={{display:'flex',justifyContent:'space-between',paddingTop:18,fontSize:20}}><strong>Total (USD)</strong><strong>${price.toFixed(2)}</strong></div><p style={{fontSize:12,color:'#708095',lineHeight:1.6}}>PayPal Sandbox test checkout charges no real money. The displayed currency selector does not change the PayPal charge, which is in USD.</p>
      </section>
      <section style={{border:'1px solid #dce5ef',borderRadius:18,padding:24,background:'#f8fbff'}}><h2 style={{marginTop:0}}>PayPal checkout</h2><p style={{color:'#60758b',lineHeight:1.6}}>Payment is verified server-side. PDF email delivery requires the store’s Supabase tracking table and verified sender email to be configured.</p><PayPalCheckout slug={p.slug} priceUSD={price.toFixed(2)} /><p style={{fontSize:12,textAlign:'center',color:'#708095',marginBottom:0,marginTop:18}}>Questions? <a href="mailto:emanualshub@gmail.com" style={{color:'#1265b0'}}>Contact eManuals Hub support</a></p></section>
    </div>
  </main>;
}
