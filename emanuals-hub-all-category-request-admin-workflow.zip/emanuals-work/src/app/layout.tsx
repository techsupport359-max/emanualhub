import type { Metadata } from "next";
import "./globals.css";
import HelpButton from "@/components/HelpButton";
import FloatingBrand from "@/components/FloatingBrand";
import { CurrencyProvider } from "@/components/CurrencyProvider";

export const metadata: Metadata = {
  title: "eManuals Hub | Repair, Service & Technical Manuals",
  description: "Find service, repair, wiring and technical manuals for vehicles, electronics and equipment.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><CurrencyProvider>{children}<FloatingBrand /><HelpButton /></CurrencyProvider></body></html>;
}
