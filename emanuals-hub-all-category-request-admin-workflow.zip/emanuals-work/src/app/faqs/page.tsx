import SiteHeader from "@/components/SiteHeader";
const faqs = [
 ["How do I find the correct manual?","Search by brand, exact model, model year and variant. Confirm the product details before purchasing."],
 ["Are all listed manuals available as PDFs?","No. Only verified, available files should be listed as purchasable. Some catalogue entries may be category or request links."],
 ["Are these official OEM manuals?","A manual is described as OEM only when its source and authorization have been verified. Original eManuals Hub guides are labelled as such."],
 ["How do downloads work?","Secure download access should be enabled only after the payment provider confirms a successful order."],
 ["Can I request a model-specific manual?","Yes. Contact Support with make, model, year, engine/variant and the type of document you need."],
 ["How do I get help?","Use the Support page or contact the listed email address."]
];
export default function FAQsPage(){return <><SiteHeader/><main className="catalog-page technical-bg"><div className="container"><div className="catalog-hero"><div className="eyebrow">Help centre</div><h1>Frequently Asked <span className="blue-text">Questions</span></h1><p className="lead">Answers about finding manuals, availability, downloads and support.</p></div><div className="faq-list">{faqs.map(([q,a])=><details key={q} className="faq-item"><summary>{q}</summary><p>{a}</p></details>)}</div></div></main></>}
