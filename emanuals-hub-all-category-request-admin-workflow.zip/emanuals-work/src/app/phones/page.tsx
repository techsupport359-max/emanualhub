import SiteHeader from "@/components/SiteHeader";
import Link from "next/link";
const items = [
  ["📱", "iPhone repair manuals", "iPhone model-specific repair, parts and troubleshooting information"],
  ["🤖", "Android phone manuals", "Samsung Galaxy, Google Pixel, OnePlus, Xiaomi, Motorola and more"],
  ["📲", "iPad & Android tablets", "Apple iPad, Samsung Galaxy Tab and Android tablet service guides"],
  ["💻", "Windows laptops & PCs", "Dell, HP, Lenovo, ASUS, Acer, MSI and other computer families"],
  ["🍎", "MacBook, iMac & Apple devices", "MacBook Air, MacBook Pro, iMac and Mac mini documentation"],
  ["🪛", "Screen, battery & camera repairs", "Device-specific replacement and service guides"],
  ["🔬", "Board-level troubleshooting", "Diagnostics, connectors, component identification and repair references"],
  ["⌚", "Wearables & accessories", "Selected smartwatch, earbud and accessory service documentation"],
  ["🖥️", "Monitors & electronics", "Displays, peripherals and consumer-electronics service guides"],
];
export default function PhonesPage() { return <><SiteHeader/><main className="catalog-page technical-bg"><div className="container"><Link className="back-link" href="/">← Back to eManuals Hub</Link><div className="catalog-hero"><div className="eyebrow">Electronics library</div><h1>Phones, Tablets & <span className="blue-text">Computers</span></h1><p className="lead">Browse repair and service documentation for iPhone, Android phones, iPad, tablets, laptops, MacBook and other electronics. Confirm the exact model identifier before starting a repair.</p><form className="searchbox catalog-search" action="/manuals"><input name="q" placeholder="Try iPhone 15, Samsung Galaxy, MacBook Pro or iPad…" aria-label="Search electronics manuals"/><button className="btn" type="submit">Search manuals →</button></form></div><div className="catalog-grid">{items.map(([icon,item,desc])=><article className="feature catalog-card" key={item}><div className="category-icon">{icon}</div><h3>{item}</h3><p className="muted">{desc}</p><Link className="text-link" href={`/manuals?q=${encodeURIComponent(item)}`}>Find a manual →</Link></article>)}</div><p className="catalog-note">Device families and trademarks are listed for compatibility search only. Availability varies; verify model number and document rights before purchase.</p></div></main></> }
