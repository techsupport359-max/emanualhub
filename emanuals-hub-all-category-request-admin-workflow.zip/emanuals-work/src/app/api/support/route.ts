import { NextResponse } from "next/server";
import { z } from "zod";
import { createSupabaseAdmin } from "@/lib/supabase-admin";

const supportSchema = z.object({
  email: z.string().trim().email().max(254),
  topic: z.enum(["manual_request", "compatibility", "payment", "download", "membership", "other"]),
  orderReference: z.string().trim().max(120).optional().default(""),
  message: z.string().trim().min(10).max(5000),
  website: z.string().max(0).optional().default(""), // honeypot: must stay empty
});

export async function POST(request: Request) {
  let raw: unknown;
  try {
    raw = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }

  const parsed = supportSchema.safeParse(raw);
  if (!parsed.success) {
    return NextResponse.json({ error: "Please check your details and try again." }, { status: 400 });
  }
  // Silently accept bot honeypot submissions without storing them.
  if (parsed.data.website) return NextResponse.json({ ok: true });

  const { email, topic, orderReference, message } = parsed.data;
  try {
    const supabase = createSupabaseAdmin();
    const { data, error } = await supabase
      .from("support_tickets")
      .insert({
        customer_email: email,
        topic,
        order_reference: orderReference || null,
        subject: topic.replaceAll("_", " "),
        message,
      })
      .select("id")
      .single();

    if (error || !data) {
      return NextResponse.json(
        { error: "Support is temporarily unavailable. Please email emanualshub@gmail.com." },
        { status: 503 },
      );
    }

    // Optional server-side email notification through Resend.
    // If not configured, ticket is still stored and the API returns the ticket reference.
    const resendKey = process.env.RESEND_API_KEY;
    const from = process.env.SUPPORT_FROM_EMAIL;
    if (resendKey && from) {
      try {
        await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            from,
            to: [process.env.SUPPORT_EMAIL || "emanualshub@gmail.com"],
            subject: `New eManuals Hub support ticket ${data.id}`,
            text: `Ticket: ${data.id}\nCustomer: ${email}\nTopic: ${topic}\nOrder reference: ${orderReference || "Not supplied"}\n\n${message}`,
          }),
        });
      } catch {
        // Do not fail ticket creation if notification delivery fails.
      }
    }

    return NextResponse.json({ ok: true, ticketId: data.id });
  } catch {
    return NextResponse.json(
      { error: "Support is not configured yet. Please email emanualshub@gmail.com." },
      { status: 503 },
    );
  }
}
