import { NextResponse } from "next/server";
import { z } from "zod";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { products, getCompetitivePriceUSD } from "@/lib/catalog";
import { createSupabaseAdmin } from "@/lib/supabase-admin";

export const runtime = "nodejs";
const schema = z.object({ orderId: z.string().min(1).max(120), slug: z.string().min(1).max(120), email: z.string().trim().email().max(254) });
function paypalBase() { return process.env.PAYPAL_BASE_URL || "https://api-m.sandbox.paypal.com"; }

async function getAccessToken() {
  const id = process.env.PAYPAL_CLIENT_ID;
  const secret = process.env.PAYPAL_CLIENT_SECRET;
  if (!id || !secret) throw new Error("PayPal is not configured.");
  const response = await fetch(`${paypalBase()}/v1/oauth2/token`, {
    method: "POST",
    headers: { Authorization: `Basic ${Buffer.from(`${id}:${secret}`).toString("base64")}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=client_credentials", cache: "no-store",
  });
  if (!response.ok) throw new Error("Could not authenticate with PayPal.");
  return (await response.json()).access_token as string;
}

export async function POST(request: Request) {
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Invalid request." }, { status: 400 }); }
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid order details." }, { status: 400 });
  const product = products.find(p => p.slug === parsed.data.slug);
  if (!product || !product.original || product.status !== "sample-guide" || !product.pdf.startsWith("/manuals/")) {
    return NextResponse.json({ error: "This manual is not enabled for automatic delivery." }, { status: 404 });
  }
  const expectedAmount = getCompetitivePriceUSD(product).toFixed(2);
  try {
    const token = await getAccessToken();
    const lookup = await fetch(`${paypalBase()}/v2/checkout/orders/${encodeURIComponent(parsed.data.orderId)}`, {
      headers: { Authorization: `Bearer ${token}` }, cache: "no-store",
    });
    if (!lookup.ok) return NextResponse.json({ error: "Could not verify PayPal order." }, { status: 400 });
    const order = await lookup.json();
    const unit = order.purchase_units?.[0];
    if (unit?.custom_id !== product.slug || unit?.reference_id !== product.slug ||
        unit?.amount?.currency_code !== "USD" || unit?.amount?.value !== expectedAmount) {
      return NextResponse.json({ error: "Order details do not match this manual." }, { status: 400 });
    }

    const admin = createSupabaseAdmin();
    const { data: tracked, error: trackingError } = await admin.from("paypal_deliveries")
      .select("id,status,customer_email,manual_slug,paypal_capture_id")
      .eq("paypal_order_id", parsed.data.orderId).maybeSingle();
    if (trackingError || !tracked) return NextResponse.json({ error: "Order tracking is missing. Contact support before retrying." }, { status: 503 });
    if (tracked.customer_email.toLowerCase() !== parsed.data.email.toLowerCase() || tracked.manual_slug !== product.slug) {
      return NextResponse.json({ error: "The email or manual does not match the original checkout." }, { status: 400 });
    }
    if (tracked.status === "delivered") return NextResponse.json({ ok: true, delivered: true, message: "This order was already delivered to your email." });

    let captureId = tracked.paypal_capture_id || "";
    if (order.status === "COMPLETED") {
      captureId = unit.payments?.captures?.[0]?.id || "";
    } else if (order.status === "APPROVED") {
      const capture = await fetch(`${paypalBase()}/v2/checkout/orders/${encodeURIComponent(parsed.data.orderId)}/capture`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", "PayPal-Request-Id": `capture-${parsed.data.orderId}` },
        body: "{}", cache: "no-store",
      });
      const result = await capture.json();
      if (!capture.ok || result.status !== "COMPLETED") return NextResponse.json({ error: "Payment is not completed. Please contact support before retrying." }, { status: 402 });
      captureId = result.purchase_units?.[0]?.payments?.captures?.[0]?.id || "";
    } else {
      return NextResponse.json({ error: "PayPal has not approved this payment." }, { status: 402 });
    }
    if (!captureId) return NextResponse.json({ error: "Payment confirmation is missing. Please contact support." }, { status: 502 });

    if (tracked.status !== "paid" || !tracked.paypal_capture_id) {
      const { error: updateError } = await admin.from("paypal_deliveries").update({
        paypal_capture_id: captureId, status: "paid", last_error: null,
      }).eq("id", tracked.id);
      if (updateError) return NextResponse.json({ error: "Payment is confirmed, but order tracking could not be updated. Contact support with your PayPal order ID." }, { status: 503 });
    }
    const deliveryId = tracked.id;

    const resendKey = process.env.RESEND_API_KEY;
    const from = process.env.MANUALS_FROM_EMAIL;
    if (!resendKey || !from) return NextResponse.json({ error: "Payment confirmed, but email delivery is not configured. Contact support with your PayPal order ID." }, { status: 503 });

    const relative = product.pdf.replace(/^\/+/, "");
    const filePath = path.join(process.cwd(), "public", relative);
    const bytes = await readFile(filePath);
    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from, to: [parsed.data.email], subject: `Your eManuals Hub PDF: ${product.title}`,
        text: `Thank you for your purchase.\\n\\nAttached is ${product.title}.\\nOrder reference: ${parsed.data.orderId}\\n\\nPlease review the guide's compatibility notes and safety warnings before use.\\n\\neManuals Hub Support`,
        attachments: [{ filename: `${product.slug}.pdf`, content: bytes.toString("base64") }],
      }),
    });
    if (!emailResponse.ok) {
      await admin.from("paypal_deliveries").update({ status: "email_failed", last_error: "Email provider rejected delivery" }).eq("id", deliveryId);
      return NextResponse.json({ error: "Payment confirmed, but the email could not be sent yet. Contact support with your PayPal order ID." }, { status: 503 });
    }
    await admin.from("paypal_deliveries").update({ status: "delivered", delivered_at: new Date().toISOString(), last_error: null }).eq("id", deliveryId);
    return NextResponse.json({ ok: true, delivered: true, message: "Payment confirmed. The PDF has been emailed." });
  } catch {
    return NextResponse.json({ error: "Payment may be confirmed, but automatic delivery could not finish. Contact support with your PayPal order ID." }, { status: 503 });
  }
}