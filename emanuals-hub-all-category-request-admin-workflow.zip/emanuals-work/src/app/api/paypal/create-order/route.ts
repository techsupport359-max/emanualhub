import { NextResponse } from "next/server";
import { z } from "zod";
import { products, getCompetitivePriceUSD } from "@/lib/catalog";
import { createSupabaseAdmin } from "@/lib/supabase-admin";

export const runtime = "nodejs";
const schema = z.object({ slug: z.string().min(1).max(120), email: z.string().trim().email().max(254) });

function paypalBase() {
  return process.env.PAYPAL_BASE_URL || "https://api-m.sandbox.paypal.com";
}
async function accessToken() {
  const id = process.env.PAYPAL_CLIENT_ID;
  const secret = process.env.PAYPAL_CLIENT_SECRET;
  if (!id || !secret) throw new Error("PayPal is not configured.");
  const response = await fetch(`${paypalBase()}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(`${id}:${secret}`).toString("base64")}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
    cache: "no-store",
  });
  if (!response.ok) throw new Error("Could not authenticate with PayPal.");
  const data = await response.json();
  return data.access_token as string;
}

export async function POST(request: Request) {
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Invalid request." }, { status: 400 }); }
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Enter a valid email and choose a manual." }, { status: 400 });
  const product = products.find(p => p.slug === parsed.data.slug);
  if (!product || !product.original || product.status !== "sample-guide" || !product.pdf.startsWith("/manuals/")) {
    return NextResponse.json({ error: "This manual is not enabled for automatic delivery yet." }, { status: 404 });
  }
  const amount = getCompetitivePriceUSD(product).toFixed(2);
  try {
    const token = await accessToken();
    const response = await fetch(`${paypalBase()}/v2/checkout/orders`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", "PayPal-Request-Id": `create-${crypto.randomUUID()}` },
      body: JSON.stringify({
        intent: "CAPTURE",
        purchase_units: [{
          reference_id: product.slug,
          custom_id: product.slug,
          description: product.title.slice(0, 127),
          amount: { currency_code: "USD", value: amount },
        }],
        payment_source: { paypal: { experience_context: { shipping_preference: "NO_SHIPPING", user_action: "PAY_NOW" } } },
      }),
      cache: "no-store",
    });
    const data = await response.json();
    if (!response.ok || !data.id) return NextResponse.json({ error: "PayPal could not create this order." }, { status: 502 });
    const admin = createSupabaseAdmin();
    const { error: trackError } = await admin.from("paypal_deliveries").insert({
      paypal_order_id: data.id, customer_email: parsed.data.email, manual_slug: product.slug,
      amount_usd_cents: Math.round(Number(amount) * 100), status: "pending",
    });
    if (trackError) return NextResponse.json({ error: "Could not record the order safely. Please retry or contact support." }, { status: 503 });
    return NextResponse.json({ id: data.id });
  } catch {
    return NextResponse.json({ error: "PayPal is not configured. Check server environment variables." }, { status: 503 });
  }
}
