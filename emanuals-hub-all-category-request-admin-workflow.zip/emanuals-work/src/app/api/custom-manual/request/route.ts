import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createSupabaseAdmin } from '@/lib/supabase-admin';
export const runtime='nodejs';
const schema=z.object({email:z.string().trim().email().max(254),category:z.string().trim().min(1).max(100),brand:z.string().trim().min(1).max(100),model:z.string().trim().min(1).max(120),year:z.string().max(30).optional().default(''),variant:z.string().max(120).optional().default(''),manualType:z.string().min(1).max(120),details:z.string().trim().min(10).max(3000),acknowledge:z.string().optional(),website:z.string().max(0).optional().default('')});
async function sendEmail(to:string,subject:string,text:string){const key=process.env.RESEND_API_KEY,from=process.env.SUPPORT_FROM_EMAIL||process.env.MANUALS_FROM_EMAIL;if(!key||!from)throw new Error('Email is not configured');const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({from,to:[to],subject,text})});if(!r.ok)throw new Error('Email failed')}
export async function POST(req:Request){let raw:unknown;try{raw=await req.json()}catch{return NextResponse.json({error:'Invalid request.'},{status:400})}const parsed=schema.safeParse(raw);if(!parsed.success)return NextResponse.json({error:'Please complete the required fields.'},{status:400});if(parsed.data.website)return NextResponse.json({ok:true});try{const admin=createSupabaseAdmin();const {data,error}=await admin.from('custom_manual_requests').insert({customer_email:parsed.data.email,category:parsed.data.category,brand:parsed.data.brand,model:parsed.data.model,model_year:parsed.data.year||null,variant:parsed.data.variant||null,manual_type:parsed.data.manualType,details:parsed.data.details,status:'requested',amount_usd_cents:null}).select('id').single();if(error||!data)throw new Error('Could not save request');const summary=`New custom manual request

Request ID: ${data.id}
Customer email: ${parsed.data.email}
Category: ${parsed.data.category}
Brand: ${parsed.data.brand}
Model: ${parsed.data.model}
Year: ${parsed.data.year||'Not supplied'}
Engine/variant: ${parsed.data.variant||'Not supplied'}
Manual type: ${parsed.data.manualType}
Details: ${parsed.data.details}

Next: verify that the requested material can be supplied, prepare and quality-check the PDF, then use the admin page to email the PDF and PayPal payment link. Do not claim manufacturer affiliation or send unlicensed material.`;await Promise.all([sendEmail(process.env.ADMIN_EMAIL||process.env.SUPPORT_EMAIL||'emanualshub@gmail.com',`NEW MANUAL REQUEST — ${parsed.data.brand} ${parsed.data.model}`,summary),sendEmail(parsed.data.email,'eManuals Hub received your manual request',`Thank you for contacting eManuals Hub. We received your request and our team will review the details. If we can fulfill it, we will email you the manual PDF together with a PayPal payment link.

Request reference: ${data.id}
Category: ${parsed.data.category}
Brand/model: ${parsed.data.brand} ${parsed.data.model}
Manual type: ${parsed.data.manualType}

This is a request receipt, not a payment confirmation or delivery promise. We will contact you if we need more details.`)]);return NextResponse.json({ok:true,requestId:data.id})}catch{return NextResponse.json({error:'We could not complete the request right now. Please try again or contact support.'},{status:503})}}
