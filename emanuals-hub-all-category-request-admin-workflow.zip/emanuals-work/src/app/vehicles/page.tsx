import SiteHeader from "@/components/SiteHeader";
import Link from "next/link";
const items = [
  ["🚗", "Car workshop manuals", "Toyota, Ford, Honda, BMW, Mercedes-Benz, Audi, Hyundai, Kia, Nissan and more"],
  ["🚚", "Cars, SUVs, vans & trucks", "Passenger vehicles, pickups, commercial vehicles and diesel trucks"],
  ["🏍️", "Motorcycle service manuals", "Honda, Yamaha, Kawasaki, Suzuki, Harley-Davidson, KTM and more"],
  ["🔧", "Engine & transmission guides", "Service procedures, specifications and maintenance information"],
  ["🔌", "Wiring diagrams & diagnostics", "Electrical diagrams, fault finding and diagnostic references"],
  ["🛞", "ATVs, UTVs & powersports", "Off-road vehicles, side-by-sides and recreational machines"],
  ["🚌", "Buses & commercial vehicles", "Fleet maintenance, chassis and workshop documentation"],
  ["🧰", "Maintenance & troubleshooting", "Scheduled service, repair procedures and fault diagnosis"],
];
export default function VehiclesPage() { return <><SiteHeader/><main className="catalog-page technical-bg"><div className="container"><Link className="back-link" href="/">← Back to eManuals Hub</Link><div className="catalog-hero"><div className="eyebrow">Vehicle library</div><h1>Cars, Bikes & <span className="blue-text">Vehicle Manuals</span></h1><p className="lead">Browse car, motorcycle, truck, van, ATV and commercial-vehicle documentation. Search by manufacturer, exact model and year to check catalogue availability.</p><form className="searchbox catalog-search" action="/manuals"><input name="q" placeholder="Try Toyota Corolla, Ford F-150, Honda or Yamaha…" aria-label="Search vehicle manuals"/><button className="btn" type="submit">Search manuals →</button></form></div><div className="catalog-grid">{items.map(([icon,item,desc])=><article className="feature catalog-card" key={item}><div className="category-icon">{icon}</div><h3>{item}</h3><p className="muted">{desc}</p><Link className="text-link" href={`/manuals?q=${encodeURIComponent(item)}`}>Find a manual →</Link></article>)}</div><p className="catalog-note">Brand names are used to help identify compatible products. Manual availability varies; confirm exact model and year before purchase.</p></div></main></> }
