"use client";

import SiteHeader from "@/components/SiteHeader";

import { useState } from "react";

export default function SupportPage() {
  const [topic, setTopic] = useState("manual_request");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ kind: "success" | "error"; text: string } | null>(null);

  async function submitRequest(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setResult(null);
    const form = new FormData(event.currentTarget);
    const payload = {
      email: String(form.get("email") || ""),
      topic,
      orderReference: String(form.get("orderReference") || ""),
      message: String(form.get("message") || ""),
      website: String(form.get("website") || ""),
    };
    try {
      const response = await fetch("/api/support", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await response.json();
      if (!response.ok || !data.ok) throw new Error(data.error || "Could not submit your request.");
      setResult({ kind: "success", text: `Your request has been received. Reference: ${data.ticketId}. Please keep this reference for follow-up.` });
      event.currentTarget.reset();
      setTopic("manual_request");
    } catch (error) {
      setResult({ kind: "error", text: error instanceof Error ? error.message : "Please email emanualshub@gmail.com." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="technical-bg" style={{maxWidth:850,margin:"44px auto",padding:24}}>
      <a href="/" style={{color:"#1769e0",fontWeight:700}}>← eManuals Hub</a>
      <p style={{color:"#1769e0",fontWeight:700,letterSpacing:".08em",textTransform:"uppercase",fontSize:".78rem",marginTop:30}}>eManuals Hub Help Centre</p>
      <h1 style={{fontSize:"clamp(2.2rem,5vw,3.2rem)",letterSpacing:"-.045em",marginBottom:10}}>We’re here to help.</h1>
      <p style={{color:"#5e6b7b",lineHeight:1.7,maxWidth:650}}>Ask about finding the right manual, compatibility, payment, downloads or your membership. Your personal phone number is not shown on this page.</p>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(240px,1fr))",gap:16,marginTop:26}}>
        <section style={{background:"#fff",border:"1px solid #e1e7ef",borderRadius:16,padding:22}}>
          <div style={{fontSize:28}}>✉️</div>
          <h2>Email support</h2>
          <p style={{color:"#5e6b7b",lineHeight:1.6}}>Email our team. Include your order reference if you have one.</p>
          <a href="mailto:emanualshub@gmail.com?subject=eManuals%20Hub%20Support" style={{display:"inline-block",background:"#1769e0",color:"#fff",padding:"11px 14px",borderRadius:9,fontWeight:700}}>Email support</a>
        </section>
        <section style={{background:"#fff",border:"1px solid #e1e7ef",borderRadius:16,padding:22}}>
          <div style={{fontSize:28}}>💬</div>
          <h2>WhatsApp help</h2>
          <p style={{color:"#5e6b7b",lineHeight:1.6}}>Private WhatsApp support will be connected through a WhatsApp Business Platform or shared team inbox. Your personal number is not published here.</p>
          <span style={{display:"inline-block",background:"#edf3fa",color:"#24415f",padding:"10px 12px",borderRadius:9,fontWeight:700}}>WhatsApp integration pending</span>
        </section>
      </div>

      <section style={{background:"#fff",border:"1px solid #e1e7ef",borderRadius:16,padding:24,marginTop:18}}>
        <h2 style={{marginTop:0}}>Send a support request</h2>
        {result && <div role="status" style={{background:result.kind==="success"?"#eaf8ef":"#fff0ed",padding:16,borderRadius:10,marginBottom:16,color:result.kind==="success"?"#175b32":"#8b2d1e"}}>{result.text}</div>}
        <form onSubmit={submitRequest} style={{display:"grid",gap:14}}>
          <label style={{display:"grid",gap:6,fontWeight:700}}>Your email
            <input required type="email" name="email" maxLength={254} placeholder="you@example.com" style={inputStyle}/>
          </label>
          <label style={{display:"grid",gap:6,fontWeight:700}}>What do you need help with?
            <select value={topic} onChange={e=>setTopic(e.target.value)} style={inputStyle}>
              <option value="manual_request">Find a manual</option><option value="compatibility">Model compatibility</option><option value="payment">Payment or order</option><option value="download">Download issue</option><option value="membership">Membership</option><option value="other">Something else</option>
            </select>
          </label>
          <label style={{display:"grid",gap:6,fontWeight:700}}>Order reference (optional)
            <input name="orderReference" maxLength={120} placeholder="Order number, if applicable" style={inputStyle}/>
          </label>
          <label style={{display:"grid",gap:6,fontWeight:700}}>How can we help?
            <textarea required name="message" minLength={10} maxLength={5000} rows={5} placeholder="Include the product brand, model and year if you need a manual." style={{...inputStyle,resize:"vertical"}}/>
          </label>
          <div aria-hidden="true" style={{position:"absolute",left:"-10000px",width:1,height:1,overflow:"hidden"}}>
            <label>Leave this field empty<input name="website" tabIndex={-1} autoComplete="off"/></label>
          </div>
          <button disabled={busy} type="submit" style={{background:busy?"#7898c5":"#1769e0",color:"#fff",border:0,padding:14,borderRadius:9,fontWeight:700,cursor:busy?"wait":"pointer"}}>{busy?"Sending…":"Send support request"}</button>
          <small style={{color:"#7b8796"}}>Never enter passwords or payment card details. Please use the email link if support submission is unavailable.</small>
        </form>
      </section>
      <p style={{fontSize:".8rem",color:"#7b8796",marginTop:20}}>Support ticket submission requires configured Supabase credentials and the schema in supabase/schema.sql. Add production rate limiting, staff-only admin access and monitoring before launch.</p>
    </main>
  );
}

const inputStyle: React.CSSProperties = {width:"100%",padding:"12px 13px",border:"1px solid #cfd8e4",borderRadius:9,background:"#fff",color:"#122033"};
