import FastDeliveryNotice from "@/components/FastDeliveryNotice";
import SiteHeader from "@/components/SiteHeader";
import Link from "next/link";
import { products, modelFamilies, getCompetitivePriceUSD } from "@/lib/catalog";
import { CurrencyPrice } from "@/components/CurrencyProvider";

const categories = [
  "Cars","Commercial Vehicles","Agriculture","Construction","Motorcycles",
  "Business & Industrial","Phones & Tablets","Laptops & Computers","Marine",
  "Engines & Electrical","Home & Garden","Education"
];
const categoryAliases: Record<string,string[]> = {
  "cars":["cars","cars & trucks","vehicle"],
  "commercial vehicles":["commercial vehicles","cars & trucks","trucks","buses"],
  "agriculture":["agriculture","tractors & agriculture","tractor"],
  "construction":["construction","heavy equipment & cranes","heavy equipment"],
  "motorcycles":["motorcycles","motorcycle"],
  "business & industrial":["business & industrial","industrial"],
  "phones & tablets":["phones & tablets","phone"],
  "laptops & computers":["laptops & computers","computer"],
  "marine":["marine"],
  "engines & electrical":["engines & electrical","engine"],
  "home & garden":["home & garden"],
  "education":["education","technical guides"]
};
export default async function CatalogPage({searchParams}:{searchParams:Promise<{q?:string;category?:string;brand?:string;model?:string;year?:string;type?:string}>}) {
 const params=await searchParams;
 const q=(params.q||"").trim().toLowerCase();
 const category=params.category||"";
 const brand=params.brand||"";
 const model=params.model||"";
 const year=params.year||"";
 const type=params.type||"";
 const matchesCategory=(p:typeof products[number])=>{
   if(!category)return true;
   const aliases=categoryAliases[category.toLowerCase()]||[category.toLowerCase()];
   return aliases.some(a=>[p.category,p.title,p.brand,p.model,p.type].join(" ").toLowerCase().includes(a));
 };
 const filtered=products.filter(p=>matchesCategory(p)
   &&(!brand||p.brand.toLowerCase()===brand.toLowerCase())
   &&(!model||p.model.toLowerCase().includes(model.toLowerCase()))
   &&(!year||p.year.toLowerCase().includes(year.toLowerCase()))
   &&(!type||p.type.toLowerCase().includes(type.toLowerCase()))
   &&(!q||[p.title,p.category,p.brand,p.model,p.type,p.description].join(" ").toLowerCase().includes(q)));
 const brands=Array.from(new Set(products.filter(matchesCategory).map(p=>p.brand))).sort();
 const models=Array.from(new Set(products.filter(p=>matchesCategory(p)&&(!brand||p.brand.toLowerCase()===brand.toLowerCase())).map(p=>p.model))).sort();
 const years=Array.from(new Set(products.filter(p=>matchesCategory(p)&&(!brand||p.brand.toLowerCase()===brand.toLowerCase())&&(!model||p.model.toLowerCase().includes(model.toLowerCase()))).map(p=>p.year))).sort();
 const types=Array.from(new Set(products.filter(matchesCategory).map(p=>p.type))).sort();
 const activeTitle=category||"All categories";
 return <><SiteHeader/><main style={{maxWidth:1180,margin:"40px auto",padding:24,color:"#10223a"}}>
  <Link href="/categories" style={{color:"#1265b0",fontWeight:700}}>← All categories</Link>
  <div style={{marginTop:24,display:"flex",justifyContent:"space-between",gap:18,alignItems:"end",flexWrap:"wrap"}}><div><p style={{color:"#1265b0",fontWeight:800,letterSpacing:2,fontSize:12}}>CATEGORY → BRAND → MODEL → YEAR → PDF</p><h1 style={{fontSize:"clamp(2rem,5vw,3.3rem)",margin:"8px 0"}}>{activeTitle} manuals</h1><p style={{color:"#586b81",maxWidth:700,lineHeight:1.7}}>Choose one category, then narrow the results by brand, model, year and manual type. We only show actual files currently in the catalogue; unavailable model-specific PDFs are not invented.</p></div>
  <form action="/catalog" style={{display:"flex",gap:8,minWidth:260}}><input type="hidden" name="category" value={category}/><input name="q" defaultValue={params.q||""} placeholder="Search within this category" style={{padding:"12px 14px",border:"1px solid #cbd5e1",borderRadius:10,minWidth:0,flex:1}}/><button style={{background:"#1265b0",color:"white",border:0,borderRadius:10,padding:"12px 16px",fontWeight:700}}>Search</button></form></div>
  <FastDeliveryNotice />
  <form action="/catalog" style={{marginTop:24,padding:18,background:"#f0f6fc",border:"1px solid #d9e7f4",borderRadius:16,display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(165px,1fr))",gap:12}}>
   <label style={{fontSize:13,fontWeight:700}}>Category<select name="category" defaultValue={category} style={selectStyle}><option value="">All categories</option>{categories.map(c=><option key={c}>{c}</option>)}</select></label>
   <label style={{fontSize:13,fontWeight:700}}>Brand<select name="brand" defaultValue={brand} style={selectStyle}><option value="">All brands in results</option>{brands.map(b=><option key={b}>{b}</option>)}</select></label>
   <label style={{fontSize:13,fontWeight:700}}>Model<select name="model" defaultValue={model} style={selectStyle}><option value="">All models in results</option>{models.map(m=><option key={m}>{m}</option>)}</select></label>
   <label style={{fontSize:13,fontWeight:700}}>Year<select name="year" defaultValue={year} style={selectStyle}><option value="">All years in results</option>{years.map(y=><option key={y}>{y}</option>)}</select></label>
   <label style={{fontSize:13,fontWeight:700}}>Manual type<select name="type" defaultValue={type} style={selectStyle}><option value="">All document types</option>{types.map(t=><option key={t}>{t}</option>)}</select></label>
   <div style={{display:"flex",gap:8,alignItems:"end"}}><button style={{background:"#1265b0",color:"white",border:0,borderRadius:10,padding:"12px 16px",fontWeight:700,flex:1}}>Apply filters</button><Link href="/catalog" style={{padding:"12px 8px",color:"#1265b0",fontWeight:700}}>Reset</Link></div>
  </form>
  <section style={{marginTop:20,padding:16,border:"1px solid #d9e7f4",borderRadius:12,background:"#f5f9fd"}}><strong>Competitive pricing policy</strong><p style={{margin:"7px 0 0",color:"#506176",lineHeight:1.6}}>When we verify a directly comparable listing for the exact same model, year and manual type, we aim to price our manual $2.50 USD below that reference. We do not guess competitor prices or compare unrelated guides. Reference prices are checked before being used.</p></section><p style={{color:"#586b81",marginTop:22}}>Showing <b>{filtered.length}</b> verified/current catalogue file{filtered.length===1?"":"s"} for these filters.</p>
  <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(270px,1fr))",gap:18,marginTop:18}}>{filtered.map(p=><article key={p.slug} style={{border:"1px solid #dce5ef",borderRadius:18,overflow:"hidden",background:"white",boxShadow:"0 8px 24px #1836540b"}}><div style={{background:"linear-gradient(135deg,#0d2440,#145b98)",color:"white",padding:20,minHeight:115}}><div style={{fontSize:12,opacity:.8}}>{p.category}</div><h2 style={{fontSize:21,lineHeight:1.25,margin:"12px 0 0"}}>{p.title}</h2></div><div style={{padding:20}}><p style={{color:"#506176",lineHeight:1.6,minHeight:72}}>{p.description}</p><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,fontSize:13,color:"#506176",margin:"16px 0"}}><span>📄 {p.pages} pages</span><span>🌐 {p.language}</span><span>🏷️ {p.type}</span><span>✓ PDF guide</span></div><div style={{display:"flex",alignItems:"baseline",gap:8,marginBottom:16}}><strong style={{fontSize:22}}><CurrencyPrice usd={getCompetitivePriceUSD(p)}/></strong><span style={{color:"#60758b",fontSize:12}}>USD base price</span></div><div style={{display:"flex",gap:9,flexWrap:"wrap"}}><Link href={`/catalog/${p.slug}`} style={{background:"#1265b0",color:"#fff",textDecoration:"none",padding:"10px 13px",borderRadius:9,fontWeight:700}}>Details & access</Link><a href={p.pdf} target="_blank" rel="noreferrer" style={{border:"1px solid #cbd5e1",color:"#18324f",textDecoration:"none",padding:"10px 13px",borderRadius:9,fontWeight:700}}>Open PDF</a></div></div></article>)}</div>
  {!filtered.length&&<section style={{marginTop:20,padding:24,background:"#fff7e8",border:"1px solid #f1dfb7",borderRadius:14}}><h2 style={{marginTop:0}}>No verified PDF matches these filters yet</h2><p style={{lineHeight:1.7,color:"#624f2c"}}>We do not have an actual, verified file for this exact category/brand/model/year combination yet. Request it and we can check for a properly licensed source; this page will not pretend a missing PDF exists.</p><a href={`mailto:emanualshub@gmail.com?subject=${encodeURIComponent("Manual request: "+[category,brand,model,year,type].filter(Boolean).join(" "))}&body=${encodeURIComponent("Category: "+category+"\nBrand: "+brand+"\nModel: "+model+"\nYear: "+year+"\nDocument type: "+type+"\n")}`} style={{display:"inline-block",marginTop:8,background:"#102a47",color:"white",textDecoration:"none",padding:"12px 16px",borderRadius:10,fontWeight:700}}>Request this exact manual ↗</a></section>}
  <p style={{fontSize:12,color:"#708095",marginTop:22,lineHeight:1.6}}>Brand/model filters are built from the current inventory only. A product is purchasable only when its exact PDF, technical accuracy and distribution rights have been checked.</p>
 </main></>;
}
const selectStyle:React.CSSProperties={display:"block",width:"100%",marginTop:7,padding:"11px 10px",border:"1px solid #cbd5e1",borderRadius:9,background:"white",color:"#10223a",font:"inherit"};
