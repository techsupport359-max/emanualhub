import FastDeliveryNotice from '@/components/FastDeliveryNotice';
import Link from 'next/link';
import { products, modelFamilies } from '@/lib/catalog';
import { CurrencyPrice } from '@/components/CurrencyProvider';

const searchAliases: Record<string, string[]> = {
  car: ['cars & trucks', 'vehicle', 'car maintenance'],
  cars: ['cars & trucks', 'vehicle', 'car maintenance'],
  truck: ['cars & trucks', 'vehicle'],
  bike: ['motorcycles', 'motorcycle'],
  motorcycle: ['motorcycles', 'motorcycle'],
  tractor: ['tractors & agriculture', 'tractor'],
  cat: ['heavy equipment & cranes', 'heavy equipment'],
  crane: ['heavy equipment & cranes', 'heavy equipment'],
  excavator: ['heavy equipment & cranes', 'heavy equipment'],
  machinery: ['heavy equipment & cranes', 'heavy equipment'],
  phone: ['phones & tablets', 'phone'],
  iphone: ['phones & tablets', 'phone'],
  android: ['phones & tablets', 'phone'],
  tablet: ['phones & tablets', 'phone'],
  laptop: ['laptops & computers', 'laptop'],
  macbook: ['laptops & computers', 'laptop'],
  computer: ['laptops & computers', 'laptop'],
};

export default async function ManualsPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = '' } = await searchParams;
  const query = q.trim().toLowerCase();
  const tokens = query.split(/[^a-z0-9]+/).filter(Boolean);
  const expanded = new Set([query, ...tokens, ...tokens.flatMap(t => searchAliases[t] || [])].filter(Boolean));
  const filtered = products.filter(p => {
    if (!query) return true;
    const haystack = [p.title, p.category, p.brand, p.model, p.type, p.description, p.compatibility].join(' ').toLowerCase();
    return haystack.includes(query) || [...expanded].some(term => term.length > 2 && haystack.includes(term));
  });

  return <main style={{maxWidth:1180,margin:'40px auto',padding:24,color:'#10223a'}}>
    <Link href="/" style={{color:'#1265b0',fontWeight:700}}>← eManuals Hub</Link>
    <div style={{marginTop:24,display:'flex',justifyContent:'space-between',gap:18,alignItems:'end',flexWrap:'wrap'}}>
      <div><p style={{color:'#1265b0',fontWeight:800,letterSpacing:2,fontSize:12}}>DIGITAL MANUAL LIBRARY</p><h1 style={{fontSize:'clamp(2rem,5vw,3.1rem)',margin:'8px 0'}}>Search manuals</h1><p style={{color:'#586b81'}}>Search term: <strong>{q || 'All available starter guides'}</strong></p></div>
      <form action="/manuals" style={{display:'flex',gap:8,minWidth:260}}><input name="q" defaultValue={q} placeholder="Brand, model or category" aria-label="Search manuals" style={{padding:'12px 14px',border:'1px solid #cbd5e1',borderRadius:10,minWidth:0,flex:1}}/><button style={{background:'#1265b0',color:'white',border:0,borderRadius:10,padding:'12px 16px',fontWeight:700}}>Search</button></form>
    </div>
    <FastDeliveryNotice />
    {filtered.length > 0 ? <>
      <p style={{color:'#586b81',lineHeight:1.7}}>Showing {filtered.length} available original eManuals Hub starter guide{filtered.length===1?'':'s'}. These are general guides, not official model-specific manufacturer service manuals.</p>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))',gap:18,marginTop:22}}>{filtered.map(p=><article key={p.slug} style={{border:'1px solid #dce5ef',borderRadius:16,overflow:'hidden',background:'#fff',boxShadow:'0 8px 24px #1836540b'}}><div style={{background:'linear-gradient(135deg,#0d2440,#145b98)',color:'#fff',padding:20,minHeight:110}}><div style={{fontSize:12,opacity:.85}}>{p.category}</div><h2 style={{fontSize:20,lineHeight:1.25,margin:'10px 0 0'}}>{p.title}</h2></div><div style={{padding:20}}><p style={{color:'#506176',lineHeight:1.6}}>{p.description}</p><p style={{fontSize:13,color:'#506176'}}>PDF · {p.pages} page · English</p><p style={{fontSize:23,fontWeight:800,margin:'12px 0'}}><CurrencyPrice usd={p.priceUSD}/></p><div style={{display:'flex',gap:9,flexWrap:'wrap'}}><Link href={`/catalog/${p.slug}`} style={{background:'#1265b0',color:'#fff',textDecoration:'none',padding:'10px 13px',borderRadius:9,fontWeight:700}}>Details</Link><a href={p.pdf} target="_blank" rel="noreferrer" style={{border:'1px solid #cbd5e1',color:'#18324f',textDecoration:'none',padding:'10px 13px',borderRadius:9,fontWeight:700}}>Open PDF</a></div></div></article>)}</div>
    </> : <section style={{padding:24,background:'#fff',border:'1px solid #dce5ef',borderRadius:14,marginTop:24}}><h2 style={{marginTop:0}}>No exact manual listed yet</h2><p style={{lineHeight:1.7,color:'#586b81'}}>We do not have a verified PDF for “{q}” in the current catalogue. You can request the exact brand, model and year; we will check availability before listing it for sale.</p><a href={`mailto:emanualshub@gmail.com?subject=${encodeURIComponent('Manual request: '+q)}&body=${encodeURIComponent('Brand:\nModel:\nYear:\nDocument needed:\n')}`} style={{display:'inline-block',background:'#1265b0',color:'#fff',textDecoration:'none',padding:'12px 16px',borderRadius:10,fontWeight:700}}>Request this manual</a></section>}
    <section style={{marginTop:36,padding:24,borderRadius:16,background:'#f0f6fc',border:'1px solid #d9e7f4'}}><h2 style={{marginTop:0}}>Browse supported categories</h2><div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))',gap:12}}>{modelFamilies.map(f=><div key={f.category} style={{background:'#fff',padding:15,borderRadius:12,border:'1px solid #dce5ef'}}><strong>{f.category}</strong><p style={{fontSize:13,color:'#5a6c80',lineHeight:1.7,marginBottom:0}}>{f.brands.join(' · ')}</p></div>)}</div></section>
    <p style={{fontSize:12,color:'#708095',marginTop:22,lineHeight:1.6}}>Only the starter guides listed above are currently available as local PDFs. Brand names indicate searchable product families and do not imply that an official manufacturer manual is available. Verify exact files and distribution rights before listing OEM manuals for sale.</p>
  </main>;
}
