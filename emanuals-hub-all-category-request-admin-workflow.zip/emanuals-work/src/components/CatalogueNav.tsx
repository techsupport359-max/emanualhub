"use client";
import Link from "next/link";
import { useState } from "react";
import { carCatalogue } from "@/lib/car-catalogue";

export default function CatalogueNav() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<"Cars" | "Commercial & Other Vehicles" | "Vehicle document types">("Cars");
  const brands = carCatalogue[active] as readonly string[];
  return <div className="catalogue-nav" onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}>
    <button className="catalogue-trigger" aria-expanded={open} onClick={() => setOpen(v => !v)} onFocus={() => setOpen(true)}>
      Catalogue <span aria-hidden="true">⌄</span>
    </button>
    {open && <div className="catalogue-mega" onKeyDown={e => { if (e.key === "Escape") setOpen(false); }}>
      <div className="catalogue-cats" role="menu" aria-label="Catalogue categories">
        {(Object.keys(carCatalogue) as Array<keyof typeof carCatalogue>).map((cat) =>
          <button key={cat} className={active === cat ? "catalogue-cat active" : "catalogue-cat"}
            onMouseEnter={() => setActive(cat as typeof active)} onFocus={() => setActive(cat as typeof active)}
            onClick={() => setActive(cat as typeof active)}>{cat}</button>)}
        <Link className="catalogue-all" href="/categories" onClick={() => setOpen(false)}>View all categories →</Link>
        <Link className="catalogue-all" href="/catalog" onClick={() => setOpen(false)}>Browse available manuals →</Link>
      </div>
      <div className="catalogue-brands">
        <div className="catalogue-brands-title">{active}</div>
        <div className="catalogue-brand-grid">
          {brands.map(brand => <Link key={brand} href={`/catalog?q=${encodeURIComponent(brand)}`} onClick={() => setOpen(false)}>{brand}</Link>)}
        </div>
        <p className="catalogue-note">Select a brand to search the current catalogue. Exact model/year manuals appear only when the file and distribution rights are verified.</p>
      </div>
    </div>}
  </div>;
}
