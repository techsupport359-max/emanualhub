export default function FastDeliveryNotice() {
  return (
    <section aria-label="Fast manual delivery" style={{display:"flex",alignItems:"center",gap:14,flexWrap:"wrap",padding:"15px 18px",border:"1px solid #cfe4fb",borderRadius:14,background:"linear-gradient(110deg,#eff7ff,#f8fbff)",color:"#123253",margin:"20px 0"}}>
      <span aria-hidden="true" style={{fontSize:28}}>⚡</span>
      <div style={{flex:"1 1 220px"}}>
        <strong style={{display:"block",fontSize:16,marginBottom:3}}>Fast Manual Delivery</strong>
        <span style={{fontSize:14,lineHeight:1.6,color:"#4d6279"}}>We work to prepare and deliver your requested manual as quickly as possible, directly to your email.</span>
      </div>
      <span style={{fontSize:12,fontWeight:700,color:"#1769b0",whiteSpace:"nowrap"}}>Secure Payment · Email Delivery</span>
    </section>
  );
}
