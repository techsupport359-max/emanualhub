import Link from "next/link";

export default function FloatingBrand() {
  return (
    <Link href="/" className="floating-brand" aria-label="eManuals Hub home">
      <span className="floating-brand-mark">e</span>
      <span>eManuals Hub</span>
    </Link>
  );
}
