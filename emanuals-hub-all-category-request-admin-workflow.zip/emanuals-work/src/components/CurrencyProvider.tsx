'use client';

import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

const currencyOptions = [
  ['USD','United States — US Dollar'],['EUR','Eurozone — Euro'],['GBP','United Kingdom — Pound Sterling'],['INR','India — Indian Rupee'],['CAD','Canada — Canadian Dollar'],['AUD','Australia — Australian Dollar'],['NZD','New Zealand — New Zealand Dollar'],['JPY','Japan — Yen'],['CNY','China — Yuan Renminbi'],['HKD','Hong Kong — Hong Kong Dollar'],['SGD','Singapore — Singapore Dollar'],['CHF','Switzerland — Swiss Franc'],['AED','United Arab Emirates — Dirham'],['SAR','Saudi Arabia — Riyal'],['PKR','Pakistan — Pakistani Rupee'],['BDT','Bangladesh — Taka'],['LKR','Sri Lanka — Rupee'],['NPR','Nepal — Nepalese Rupee'],['MYR','Malaysia — Ringgit'],['IDR','Indonesia — Rupiah'],['PHP','Philippines — Peso'],['THB','Thailand — Baht'],['VND','Vietnam — Dong'],['KRW','South Korea — Won'],['TWD','Taiwan — New Taiwan Dollar'],['BRL','Brazil — Real'],['MXN','Mexico — Mexican Peso'],['ARS','Argentina — Peso'],['CLP','Chile — Peso'],['COP','Colombia — Peso'],['PEN','Peru — Sol'],['ZAR','South Africa — Rand'],['NGN','Nigeria — Naira'],['KES','Kenya — Shilling'],['GHS','Ghana — Cedi'],['EGP','Egypt — Pound'],['MAD','Morocco — Dirham'],['TRY','Türkiye — Turkish Lira'],['PLN','Poland — Zloty'],['CZK','Czechia — Koruna'],['HUF','Hungary — Forint'],['RON','Romania — Leu'],['SEK','Sweden — Krona'],['NOK','Norway — Krone'],['DKK','Denmark — Krone'],['ISK','Iceland — Krona'],['ILS','Israel — New Shekel'],['QAR','Qatar — Riyal'],['KWD','Kuwait — Dinar'],['BHD','Bahrain — Dinar'],['OMR','Oman — Rial'],['JOD','Jordan — Dinar'],['UAH','Ukraine — Hryvnia'],['KZT','Kazakhstan — Tenge'],['UZS','Uzbekistan — Som'],['GEL','Georgia — Lari'],['THB','Thailand — Baht'],['XOF','West African CFA franc'],['XAF','Central African CFA franc'],['DOP','Dominican Republic — Peso'],['JMD','Jamaica — Dollar'],['TTD','Trinidad and Tobago — Dollar'],['UYU','Uruguay — Peso'],['BOB','Bolivia — Boliviano'],['CRC','Costa Rica — Colón'],['GTQ','Guatemala — Quetzal'],['ETB','Ethiopia — Birr'],['TZS','Tanzania — Shilling'],['UGX','Uganda — Shilling'],['MUR','Mauritius — Rupee'],['FJD','Fiji — Dollar'],['XCD','Eastern Caribbean Dollar'],['ALL','Albania — Lek'],['RSD','Serbia — Dinar'],['BGN','Bulgaria — Lev'],['HRK','Croatia — legacy Kuna'],['ISK','Iceland — Krona']
] as const;

type CurrencyCode = typeof currencyOptions[number][0];
type CurrencyContextValue = { currency: string; setCurrency: (code: string) => void; formatUSD: (usd: number) => string; ratesUpdated: boolean };
const CurrencyContext = createContext<CurrencyContextValue | null>(null);
const fallbackRates: Record<string, number> = {USD:1,EUR:0.92,GBP:0.79,INR:83.5,CAD:1.36,AUD:1.52,NZD:1.65,JPY:149,CNY:7.1,HKD:7.8,SGD:1.34,CHF:0.88,AED:3.6725,SAR:3.75,PKR:278,BDT:110,LKR:300,NPR:133,MYR:4.7,IDR:15700,PHP:56,THB:36.5,VND:24500,KRW:1340,TWD:32,BRL:5.1,MXN:17.2,ARS:950,CLP:930,COP:4100,PEN:3.75,ZAR:18.2,NGN:1500,KES:129,GHS:15.5,EGP:48,MAD:9.9,TRY:32.5,PLN:4,CZK:23.2,HUF:360,RON:4.58,SEK:10.5,NOK:10.7,DKK:6.87,ISK:138,ILS:3.7,QAR:3.64,KWD:0.307,BHD:0.376,OMR:0.385,JOD:0.709,UAH:40,KZT:470,UZS:12600,GEL:2.7,XOF:605,XAF:605,DOP:59,JMD:156,TTD:6.78,UYU:39,BOB:6.9,CRC:520,GTQ:7.8,ETB:57,TZS:2700,UGX:3800,MUR:46,FJD:2.25,XCD:2.7,ALL:93,RSD:108,BGN:1.8,HRK:6.9};

export function CurrencyProvider({ children }: { children: React.ReactNode }) {
  const [currency, setCurrencyState] = useState('USD');
  const [rates, setRates] = useState<Record<string, number>>(fallbackRates);
  const [ratesUpdated, setRatesUpdated] = useState(false);

  useEffect(() => {
    const saved = window.localStorage.getItem('emanuals-currency');
    if (saved && currencyOptions.some(([code]) => code === saved)) setCurrencyState(saved);
    fetch('https://open.er-api.com/v6/latest/USD')
      .then((r) => { if (!r.ok) throw new Error('Rate lookup failed'); return r.json(); })
      .then((data) => { if (data?.result === 'success' && data.rates) { setRates(data.rates); setRatesUpdated(true); } })
      .catch(() => { /* Use clearly labelled fallback estimates when live rates are unavailable. */ });
  }, []);

  const setCurrency = (code: string) => {
    if (!currencyOptions.some(([item]) => item === code)) return;
    setCurrencyState(code);
    window.localStorage.setItem('emanuals-currency', code);
  };

  const value = useMemo<CurrencyContextValue>(() => ({
    currency, setCurrency, ratesUpdated,
    formatUSD: (usd: number) => {
      const amount = usd * (rates[currency] ?? 1);
      try { return new Intl.NumberFormat('en', { style: 'currency', currency, maximumFractionDigits: ['JPY','KRW','VND','CLP','ISK','UGX','XOF','XAF'].includes(currency) ? 0 : 2 }).format(amount); }
      catch { return `${currency} ${amount.toFixed(2)}`; }
    }
  }), [currency, rates, ratesUpdated]);

  return <CurrencyContext.Provider value={value}>
    <div style={{display:'flex',justifyContent:'flex-end',alignItems:'center',gap:10,padding:'9px clamp(14px,4vw,42px)',background:'#edf5fc',borderBottom:'1px solid #d9e6f2',fontSize:13,color:'#18324f',flexWrap:'wrap'}}>
      <span aria-hidden="true">🌐</span><label htmlFor="site-currency" style={{fontWeight:700}}>Currency / country</label>
      <select id="site-currency" value={currency} onChange={(e) => setCurrency(e.target.value)} style={{maxWidth:'min(100%,330px)',padding:'8px 10px',border:'1px solid #b8cde0',borderRadius:9,background:'#fff',color:'#18324f'}}>
        {currencyOptions.map(([code,label]) => <option key={`${code}-${label}`} value={code}>{label} ({code})</option>)}
      </select>
      <span style={{color:'#61758a',fontSize:11}}>{ratesUpdated ? 'Indicative live exchange rate' : 'Estimated rate · live rate unavailable'}</span>
    </div>
    {children}
  </CurrencyContext.Provider>;
}

export function CurrencyPrice({ usd, style }: { usd: number; style?: React.CSSProperties }) {
  const context = useContext(CurrencyContext);
  if (!context) return <span style={style}>${usd.toFixed(2)}</span>;
  return <span style={style}>{context.formatUSD(usd)}</span>;
}
