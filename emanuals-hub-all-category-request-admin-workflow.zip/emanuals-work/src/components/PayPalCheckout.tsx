 'use client';

import { useEffect, useRef, useState } from 'react';

declare global {
  interface Window {
    paypal?: {
      Buttons: (options: {
        createOrder: () => Promise<string>;
        onApprove: (data: { orderID: string }) => Promise<void>;
        onError: (error: unknown) => void;
        onCancel?: () => void;
      }) => { render: (selector: HTMLElement) => Promise<void> };
    };
  }
}

export function PayPalCheckout({ slug, priceUSD }: { slug: string; priceUSD: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [email, setEmail] = useState('');
  const emailRef = useRef('');
  const [status, setStatus] = useState('Enter your email, then continue with PayPal Sandbox.');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const clientId = process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID;
    if (!clientId || !containerRef.current) {
      setStatus('PayPal Sandbox is not configured yet. Add the public Sandbox Client ID in Netlify environment variables.');
      return;
    }
    let active = true;
    const renderButtons = async () => {
      const existing = document.querySelector<HTMLScriptElement>('script[data-paypal-sdk="true"]');
      if (!window.paypal && !existing) {
        const script = document.createElement('script');
        script.src = `https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(clientId)}&currency=USD&intent=capture`;
        script.async = true;
        script.dataset.paypalSdk = 'true';
        document.body.appendChild(script);
        await new Promise<void>((resolve, reject) => {
          script.onload = () => resolve();
          script.onerror = () => reject(new Error('PayPal SDK failed to load.'));
        });
      } else if (!window.paypal && existing) {
        await new Promise<void>((resolve, reject) => {
          existing.addEventListener('load', () => resolve(), { once: true });
          existing.addEventListener('error', () => reject(new Error('PayPal SDK failed to load.')), { once: true });
        });
      }
      if (!active || !window.paypal || !containerRef.current) return;
      containerRef.current.innerHTML = '';
      await window.paypal.Buttons({
        createOrder: async () => {
          const validEmail = emailRef.current.trim();
          if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(validEmail)) {
            setStatus('Enter a valid email address before paying.');
            throw new Error('Valid email required.');
          }
          setBusy(true);
          setStatus('Creating secure PayPal order…');
          const response = await fetch('/api/paypal/create-order', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ slug, email: validEmail }),
          });
          const data = await response.json();
          if (!response.ok || !data.id) throw new Error(data.error || 'Could not create PayPal order.');
          setStatus('Order created. Finish payment in the PayPal window.');
          return data.id as string;
        },
        onApprove: async (data) => {
          setStatus('Verifying payment and sending your PDF…');
          const response = await fetch('/api/paypal/capture-order', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderId: data.orderID, slug, email: emailRef.current.trim() }),
          });
          const result = await response.json();
          if (!response.ok) throw new Error(result.error || 'Payment or email delivery needs attention.');
          setStatus(result.message || 'Payment verified.');
          setBusy(false);
        },
        onCancel: () => { setStatus('Payment cancelled. You have not been charged by this checkout attempt.'); setBusy(false); },
        onError: (error) => {
          setStatus(error instanceof Error ? error.message : 'PayPal checkout encountered an error. Please retry or contact support.');
          setBusy(false);
        },
      }).render(containerRef.current);
    };
    renderButtons().catch((error: unknown) => {
      setStatus(error instanceof Error ? error.message : 'PayPal could not be loaded.');
    });
    return () => { active = false; };
  }, [slug]);

  return <div style={{ display: 'grid', gap: 12 }}>
    <label htmlFor="delivery-email" style={{ fontSize: 13, fontWeight: 700 }}>Email for PDF delivery</label>
    <input id="delivery-email" type="email" autoComplete="email" required value={email} onChange={(e) => { setEmail(e.target.value); emailRef.current = e.target.value; }}
      placeholder="you@example.com" style={{ width: '100%', boxSizing: 'border-box', padding: 13, border: '1px solid #cbd9e8', borderRadius: 10, background: '#fff', color: '#10223a' }} />
    <div ref={containerRef} />
    <p role="status" aria-live="polite" style={{ margin: 0, fontSize: 12, lineHeight: 1.6, color: status.toLowerCase().includes('sent') || status.toLowerCase().includes('emailed') ? '#087f5b' : '#60758b' }}>{status}</p>
    <p style={{ margin: 0, fontSize: 11, color: '#708095' }}>Sandbox/test mode only until the merchant account, delivery email and live credentials are separately verified. Checkout currency: USD {priceUSD}.</p>
  </div>;
}
