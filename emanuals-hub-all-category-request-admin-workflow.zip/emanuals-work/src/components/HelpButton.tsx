"use client";

const whatsappNumber = (process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "19412873109").replace(/[^\d]/g, "");
const supportEmail = process.env.NEXT_PUBLIC_SUPPORT_EMAIL || "emanualshub@gmail.com";

export default function HelpButton() {
  const message = encodeURIComponent("Hi eManuals Hub, I need help with a manual, order, or download.");
  const baseStyle: React.CSSProperties = {
    display: "flex", alignItems: "center", justifyContent: "center", gap: 9,
    minWidth: 150, padding: "13px 16px", borderRadius: 999, color: "#fff",
    textDecoration: "none", fontWeight: 800, fontSize: 14,
    boxShadow: "0 8px 24px #0b1d3433", border: "2px solid #fff",
    fontFamily: "inherit", boxSizing: "border-box"
  };

  return (
    <div aria-label="Direct customer support" style={{ position: "fixed", right: 18, bottom: 18, zIndex: 1000, display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 10, fontFamily: "inherit" }}>
      <a href={`mailto:${supportEmail}?subject=${encodeURIComponent("eManuals Hub Support")}&body=${message}`} style={{ ...baseStyle, background: "#1769e0" }} aria-label="Email eManuals Hub support">
        <span aria-hidden="true" style={{ fontSize: 19 }}>✉</span> Email Help
      </a>
      <a href={`https://wa.me/${whatsappNumber}?text=${message}`} target="_blank" rel="noopener noreferrer" style={{ ...baseStyle, background: "#20b858" }} aria-label="Chat with eManuals Hub on WhatsApp">
        <span aria-hidden="true" style={{ fontSize: 20 }}>☏</span> WhatsApp Help
      </a>
    </div>
  );
}
