export type ManualProduct = {
  slug: string; title: string; category: string; brand: string; model: string;
  year: string; type: string; language: string; pages: number; description: string;
  compatibility: string; priceINR: number; priceUSD: number; pdf: string;
  original: boolean; status: 'sample-guide' | 'request-model-manual';
  /** Competitor price only when the exact same model/year/manual type is verified. */
  competitorReferencePriceUSD?: number;
  competitorReferenceURL?: string;
  competitorPriceCheckedAt?: string;
};

/** Undercut only a verified, directly comparable competitor listing by $2.50.
 * Never compare generic guides against unrelated OEM manuals or guess missing prices. */
export function getCompetitivePriceUSD(product: ManualProduct): number {
  const reference = product.competitorReferencePriceUSD;
  if (typeof reference !== 'number' || !Number.isFinite(reference) || reference <= 2.50 || !product.competitorReferenceURL || !product.competitorPriceCheckedAt) {
    return product.priceUSD;
  }
  return Math.round((reference - 2.50) * 100) / 100;
}

// These are original general starter guides, not OEM model-specific service manuals.
// Do not mark manufacturer PDFs as available until the exact file and distribution rights are verified.
export const products: ManualProduct[] = [
  {slug:'car-maintenance-starter',title:'Car Maintenance Starter Guide',category:'Cars & Trucks',brand:'eManuals Hub',model:'General checklist',year:'All years (general)',type:'Maintenance guide',language:'English',pages:1,description:'A practical introductory checklist for routine visual inspections and safer maintenance planning.',compatibility:'General education only. Not a substitute for the exact vehicle owner/workshop manual, specifications or repair procedures.',priceINR:199,priceUSD:4.99,pdf:'/manuals/car-maintenance-starter.pdf',original:true,status:'sample-guide'},
  {slug:'motorcycle-maintenance-starter',title:'Motorcycle Maintenance Starter Guide',category:'Motorcycles',brand:'eManuals Hub',model:'General checklist',year:'All years (general)',type:'Maintenance guide',language:'English',pages:1,description:'A starter checklist covering pre-ride checks, safe work habits and model identification.',compatibility:'General education only. Not an OEM repair manual; use the manufacturer’s exact model specifications.',priceINR:199,priceUSD:4.99,pdf:'/manuals/motorcycle-maintenance-starter.pdf',original:true,status:'sample-guide'},
  {slug:'tractor-maintenance-starter',title:'Tractor & Farm Equipment Starter Guide',category:'Tractors & Agriculture',brand:'eManuals Hub',model:'General checklist',year:'All years (general)',type:'Maintenance guide',language:'English',pages:1,description:'A general checklist for safer tractor inspections, implement handling and maintenance preparation.',compatibility:'Not model-specific. Always use the manufacturer’s operator and service manual for procedures and specifications.',priceINR:249,priceUSD:5.99,pdf:'/manuals/tractor-maintenance-starter.pdf',original:true,status:'sample-guide'},
  {slug:'heavy-equipment-safety-starter',title:'Heavy Equipment & Crane Safety Starter Guide',category:'Heavy Equipment & Cranes',brand:'eManuals Hub',model:'General checklist',year:'All years (general)',type:'Safety guide',language:'English',pages:1,description:'An introductory safety checklist for pre-start checks, work zones and maintenance isolation.',compatibility:'Not an operator certification or OEM manual. Follow the machine-specific manual and applicable regulations.',priceINR:249,priceUSD:5.99,pdf:'/manuals/heavy-equipment-safety-starter.pdf',original:true,status:'sample-guide'},
  {slug:'phone-repair-safety-starter',title:'Phone & Tablet Repair Safety Starter Guide',category:'Phones & Tablets',brand:'eManuals Hub',model:'General checklist',year:'All years (general)',type:'Repair safety guide',language:'English',pages:1,description:'A practical starter guide to device identification, battery hazards and ESD-safe repair preparation.',compatibility:'Not an official Apple, Samsung or other manufacturer service manual; no model-specific disassembly steps.',priceINR:149,priceUSD:3.99,pdf:'/manuals/phone-repair-safety-starter.pdf',original:true,status:'sample-guide'},
  {slug:'laptop-diagnostics-starter',title:'Laptop & MacBook Diagnostics Starter Guide',category:'Laptops & Computers',brand:'eManuals Hub',model:'General checklist',year:'All years (general)',type:'Diagnostics guide',language:'English',pages:1,description:'An introductory checklist for safe preparation, model identification and basic troubleshooting planning.',compatibility:'Not an official Apple, Dell, HP or Lenovo service manual; follow exact model-specific service information.',priceINR:149,priceUSD:3.99,pdf:'/manuals/laptop-diagnostics-starter.pdf',original:true,status:'sample-guide'},
];

export const modelFamilies = [
  {category:'Cars & Trucks',brands:['Toyota','Ford','BMW','Honda','Mercedes-Benz','Volkswagen','Chevrolet','Hyundai','Kia','Nissan','Tesla','Volvo','Audi','Jeep','Ram']},
  {category:'Motorcycles',brands:['Honda','Yamaha','Kawasaki','Suzuki','Harley-Davidson','Ducati','BMW Motorrad','Royal Enfield','KTM','Triumph']},
  {category:'Tractors & Agriculture',brands:['John Deere','New Holland','Kubota','Massey Ferguson','Case IH','Fendt','Mahindra','Sonalika','Deutz-Fahr','Claas']},
  {category:'Heavy Equipment & Cranes',brands:['Caterpillar (CAT)','Komatsu','JCB','Hitachi','Volvo CE','Liebherr','Tadano','Terex','XCMG','SANY','Doosan / DEVELON']},
  {category:'Phones & Tablets',brands:['Apple iPhone','Samsung Galaxy','Google Pixel','OnePlus','Xiaomi','Motorola','Oppo','Vivo','iPad','Samsung Galaxy Tab']},
  {category:'Laptops & Computers',brands:['Apple MacBook / iMac','Dell','HP','Lenovo','ASUS','Acer','Microsoft Surface','MSI','Framework']},
];
